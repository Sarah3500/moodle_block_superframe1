Changes
=======

V401.1.0
---------
1. Moodle 4.1 version.
2. Add COPYING.txt.
